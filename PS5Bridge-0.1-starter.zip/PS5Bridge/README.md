# PS5Bridge

Clean-room experimental PS5-to-Windows compatibility-layer research project.

## Current milestone
This starter build provides:
- ELF64 parsing and validation
- executable/module inspection
- program-header listing
- basic virtual-memory abstraction
- HLE/NID registry scaffolding
- structured logging
- Vulkan capability bootstrap (optional)
- test scaffolding

It does **not** bypass DRM, decrypt protected content, provide Sony keys/firmware, or bundle copyrighted game files.

## Build
Requirements:
- Windows 10/11 x64
- Visual Studio 2022 with Desktop C++
- CMake 3.24+

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\ps5bridge.exe path\to\test.elf
```

Optional Vulkan:
```powershell
cmake -S . -B build -DPS5BRIDGE_ENABLE_VULKAN=ON
```

## Roadmap
See `docs/ROADMAP.md`.
