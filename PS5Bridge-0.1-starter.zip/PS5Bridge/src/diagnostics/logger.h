#pragma once
#include <string_view>

namespace ps5b {
enum class LogLevel { Info, Warning, Error, Debug };
void log(LogLevel level, std::string_view message);
}
