#include "diagnostics/logger.h"
#include <chrono>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <mutex>

namespace ps5b {
static std::mutex g_logMutex;

void log(LogLevel level, std::string_view message) {
    std::scoped_lock lock(g_logMutex);
    const char* tag = "INFO";
    switch (level) {
        case LogLevel::Warning: tag = "WARN"; break;
        case LogLevel::Error:   tag = "ERR "; break;
        case LogLevel::Debug:   tag = "DBG "; break;
        default: break;
    }

    auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &now);
#else
    localtime_r(&now, &tm);
#endif
    std::cerr << "[" << std::put_time(&tm, "%H:%M:%S") << "] [" << tag << "] " << message << "\n";
}
}
