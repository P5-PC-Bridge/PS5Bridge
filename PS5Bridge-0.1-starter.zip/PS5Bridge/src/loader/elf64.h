#pragma once
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace ps5b {

struct Elf64ProgramHeader {
    std::uint32_t type{};
    std::uint32_t flags{};
    std::uint64_t offset{};
    std::uint64_t vaddr{};
    std::uint64_t paddr{};
    std::uint64_t fileSize{};
    std::uint64_t memorySize{};
    std::uint64_t align{};
};

struct Elf64Image {
    std::filesystem::path path;
    std::uint16_t type{};
    std::uint16_t machine{};
    std::uint64_t entry{};
    std::vector<Elf64ProgramHeader> programHeaders;
};

class Elf64Parser {
public:
    static Elf64Image parseFile(const std::filesystem::path& path);
    static std::string describe(const Elf64Image& image);
};

}
