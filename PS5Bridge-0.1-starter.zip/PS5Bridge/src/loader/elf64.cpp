#include "loader/elf64.h"
#include <array>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>

namespace ps5b {
#pragma pack(push,1)
struct RawElf64Header {
    unsigned char ident[16];
    std::uint16_t type;
    std::uint16_t machine;
    std::uint32_t version;
    std::uint64_t entry;
    std::uint64_t phoff;
    std::uint64_t shoff;
    std::uint32_t flags;
    std::uint16_t ehsize;
    std::uint16_t phentsize;
    std::uint16_t phnum;
    std::uint16_t shentsize;
    std::uint16_t shnum;
    std::uint16_t shstrndx;
};

struct RawElf64ProgramHeader {
    std::uint32_t type;
    std::uint32_t flags;
    std::uint64_t offset;
    std::uint64_t vaddr;
    std::uint64_t paddr;
    std::uint64_t filesz;
    std::uint64_t memsz;
    std::uint64_t align;
};
#pragma pack(pop)

static void require(bool ok, const char* msg) {
    if (!ok) throw std::runtime_error(msg);
}

Elf64Image Elf64Parser::parseFile(const std::filesystem::path& path) {
    std::ifstream f(path, std::ios::binary);
    require(static_cast<bool>(f), "Unable to open file");

    RawElf64Header h{};
    f.read(reinterpret_cast<char*>(&h), sizeof(h));
    require(f.gcount() == static_cast<std::streamsize>(sizeof(h)), "File too small for ELF64 header");
    require(h.ident[0] == 0x7f && h.ident[1] == 'E' && h.ident[2] == 'L' && h.ident[3] == 'F',
            "Not an ELF file");
    require(h.ident[4] == 2, "Not ELF64");
    require(h.ident[5] == 1, "Only little-endian ELF64 is supported");
    require(h.phentsize == sizeof(RawElf64ProgramHeader) || h.phnum == 0,
            "Unexpected ELF64 program-header size");

    f.seekg(0, std::ios::end);
    const auto fileSize = static_cast<std::uint64_t>(f.tellg());
    require(h.phoff <= fileSize, "Program-header table starts outside file");
    require(h.phnum == 0 || h.phoff + (static_cast<std::uint64_t>(h.phnum) * h.phentsize) <= fileSize,
            "Program-header table exceeds file");

    Elf64Image out{};
    out.path = path;
    out.type = h.type;
    out.machine = h.machine;
    out.entry = h.entry;
    out.programHeaders.reserve(h.phnum);

    f.seekg(static_cast<std::streamoff>(h.phoff), std::ios::beg);
    for (std::uint16_t i = 0; i < h.phnum; ++i) {
        RawElf64ProgramHeader p{};
        f.read(reinterpret_cast<char*>(&p), sizeof(p));
        require(static_cast<bool>(f), "Failed to read program header");
        require(p.offset <= fileSize, "Segment offset outside file");
        require(p.filesz <= fileSize - p.offset, "Segment exceeds file");
        out.programHeaders.push_back({
            p.type, p.flags, p.offset, p.vaddr, p.paddr, p.filesz, p.memsz, p.align
        });
    }
    return out;
}

std::string Elf64Parser::describe(const Elf64Image& image) {
    std::ostringstream s;
    s << "File: " << image.path.string() << "\n";
    s << "ELF64 machine: 0x" << std::hex << image.machine << std::dec << "\n";
    s << "Type: " << image.type << "\n";
    s << "Entry: 0x" << std::hex << image.entry << std::dec << "\n";
    s << "Program headers: " << image.programHeaders.size() << "\n";
    for (std::size_t i = 0; i < image.programHeaders.size(); ++i) {
        const auto& p = image.programHeaders[i];
        s << "  [" << i << "] type=0x" << std::hex << p.type
          << " flags=0x" << p.flags
          << " off=0x" << p.offset
          << " vaddr=0x" << p.vaddr
          << " filesz=0x" << p.fileSize
          << " memsz=0x" << p.memorySize
          << " align=0x" << p.align << std::dec << "\n";
    }
    return s.str();
}
}
