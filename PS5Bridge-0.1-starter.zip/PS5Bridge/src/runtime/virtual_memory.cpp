#include "runtime/virtual_memory.h"
#include <algorithm>
#include <limits>

namespace ps5b {

static bool rangesOverlap(std::uint64_t a, std::size_t as, std::uint64_t b, std::size_t bs) {
    if (as == 0 || bs == 0) return false;
    const auto aEnd = a + static_cast<std::uint64_t>(as - 1);
    const auto bEnd = b + static_cast<std::uint64_t>(bs - 1);
    if (aEnd < a || bEnd < b) return true;
    return !(aEnd < b || bEnd < a);
}

bool VirtualMemory::map(std::uint64_t guestAddress, std::size_t size, MemoryProtection protection) {
    if (size == 0) return false;
    for (const auto& r : regions_) {
        if (rangesOverlap(guestAddress, size, r.guestAddress, r.size)) return false;
    }
    MemoryRegion r{};
    r.guestAddress = guestAddress;
    r.size = size;
    r.protection = protection;
    r.storage.resize(size);
    regions_.push_back(std::move(r));
    return true;
}

bool VirtualMemory::unmap(std::uint64_t guestAddress) {
    auto it = std::find_if(regions_.begin(), regions_.end(),
        [&](const auto& r){ return r.guestAddress == guestAddress; });
    if (it == regions_.end()) return false;
    regions_.erase(it);
    return true;
}

std::optional<std::size_t> VirtualMemory::findRegion(std::uint64_t guestAddress) const {
    for (std::size_t i = 0; i < regions_.size(); ++i) {
        const auto& r = regions_[i];
        if (guestAddress >= r.guestAddress &&
            guestAddress - r.guestAddress < static_cast<std::uint64_t>(r.size)) return i;
    }
    return std::nullopt;
}
}
