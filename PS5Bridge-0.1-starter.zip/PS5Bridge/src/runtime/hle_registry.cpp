#include "runtime/hle_registry.h"

namespace ps5b {

bool HleRegistry::registerSymbol(std::uint64_t nid, HleSymbol symbol) {
    return symbols_.emplace(nid, std::move(symbol)).second;
}

const HleSymbol* HleRegistry::resolve(std::uint64_t nid) const {
    auto it = symbols_.find(nid);
    return it == symbols_.end() ? nullptr : &it->second;
}

}
