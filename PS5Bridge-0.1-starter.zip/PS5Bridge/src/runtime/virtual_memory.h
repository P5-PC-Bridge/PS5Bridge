#pragma once
#include <cstddef>
#include <cstdint>
#include <optional>
#include <vector>

namespace ps5b {

enum class MemoryProtection : std::uint8_t {
    None = 0, Read = 1, Write = 2, Execute = 4
};

struct MemoryRegion {
    std::uint64_t guestAddress{};
    std::size_t size{};
    MemoryProtection protection{MemoryProtection::None};
    std::vector<std::byte> storage;
};

class VirtualMemory {
public:
    bool map(std::uint64_t guestAddress, std::size_t size, MemoryProtection protection);
    bool unmap(std::uint64_t guestAddress);
    std::optional<std::size_t> findRegion(std::uint64_t guestAddress) const;
    const std::vector<MemoryRegion>& regions() const { return regions_; }

private:
    std::vector<MemoryRegion> regions_;
};

}
