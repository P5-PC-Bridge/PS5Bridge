#pragma once
#include <cstdint>
#include <functional>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>

namespace ps5b {

using HleFunction = std::function<std::int64_t()>;

struct HleSymbol {
    std::string library;
    std::string name;
    HleFunction function;
};

class HleRegistry {
public:
    bool registerSymbol(std::uint64_t nid, HleSymbol symbol);
    const HleSymbol* resolve(std::uint64_t nid) const;
    std::size_t size() const { return symbols_.size(); }

private:
    std::unordered_map<std::uint64_t, HleSymbol> symbols_;
};

}
