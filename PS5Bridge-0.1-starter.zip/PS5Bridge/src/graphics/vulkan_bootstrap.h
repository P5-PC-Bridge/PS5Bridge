#pragma once
#include <string>
#include <vector>

namespace ps5b {
struct VulkanDeviceInfo {
    std::string name;
    unsigned apiVersion{};
};
std::vector<VulkanDeviceInfo> enumerateVulkanDevices();
}
