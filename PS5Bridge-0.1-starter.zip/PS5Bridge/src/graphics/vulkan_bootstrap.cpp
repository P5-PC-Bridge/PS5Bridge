#include "graphics/vulkan_bootstrap.h"
#include <vulkan/vulkan.h>
#include <stdexcept>

namespace ps5b {
std::vector<VulkanDeviceInfo> enumerateVulkanDevices() {
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "PS5Bridge";
    app.applicationVersion = VK_MAKE_VERSION(0,1,0);
    app.pEngineName = "PS5Bridge";
    app.engineVersion = VK_MAKE_VERSION(0,1,0);
    app.apiVersion = VK_API_VERSION_1_1;

    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &app;

    VkInstance instance = VK_NULL_HANDLE;
    if (vkCreateInstance(&ci, nullptr, &instance) != VK_SUCCESS)
        throw std::runtime_error("vkCreateInstance failed");

    std::uint32_t count = 0;
    vkEnumeratePhysicalDevices(instance, &count, nullptr);
    std::vector<VkPhysicalDevice> devices(count);
    if (count) vkEnumeratePhysicalDevices(instance, &count, devices.data());

    std::vector<VulkanDeviceInfo> out;
    for (auto dev : devices) {
        VkPhysicalDeviceProperties p{};
        vkGetPhysicalDeviceProperties(dev, &p);
        out.push_back({p.deviceName, p.apiVersion});
    }
    vkDestroyInstance(instance, nullptr);
    return out;
}
}
