#include "diagnostics/logger.h"
#include "loader/elf64.h"
#include "runtime/hle_registry.h"
#include "runtime/virtual_memory.h"
#ifdef PS5BRIDGE_ENABLE_VULKAN
#include "graphics/vulkan_bootstrap.h"
#endif

#include <iostream>

int main(int argc, char** argv) {
    using namespace ps5b;
    log(LogLevel::Info, "PS5Bridge 0.1 starting");

#ifdef PS5BRIDGE_ENABLE_VULKAN
    try {
        auto devices = enumerateVulkanDevices();
        std::cout << "Vulkan devices: " << devices.size() << "\n";
        for (const auto& d : devices) std::cout << "  " << d.name << "\n";
    } catch (const std::exception& e) {
        log(LogLevel::Warning, e.what());
    }
#endif

    if (argc < 2) {
        std::cout << "Usage: ps5bridge <elf-file>\n";
        return 0;
    }

    try {
        auto image = Elf64Parser::parseFile(argv[1]);
        std::cout << Elf64Parser::describe(image);

        VirtualMemory vm;
        for (const auto& ph : image.programHeaders) {
            if (ph.type != 1 || ph.memorySize == 0) continue; // PT_LOAD
            MemoryProtection prot = MemoryProtection::None;
            if (ph.flags & 4) prot = static_cast<MemoryProtection>(static_cast<unsigned>(prot) | 1u);
            if (ph.flags & 2) prot = static_cast<MemoryProtection>(static_cast<unsigned>(prot) | 2u);
            if (ph.flags & 1) prot = static_cast<MemoryProtection>(static_cast<unsigned>(prot) | 4u);
            if (!vm.map(ph.vaddr, static_cast<std::size_t>(ph.memorySize), prot)) {
                log(LogLevel::Warning, "Unable to map one PT_LOAD segment into guest-memory model");
            }
        }

        std::cout << "Mapped guest regions: " << vm.regions().size() << "\n";
        log(LogLevel::Info, "Analysis complete");
        return 0;
    } catch (const std::exception& e) {
        log(LogLevel::Error, e.what());
        return 1;
    }
}
