#include "runtime/hle_registry.h"
#include "runtime/virtual_memory.h"
#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    using namespace ps5b;

    VirtualMemory vm;
    assert(vm.map(0x1000, 0x1000, MemoryProtection::Read));
    assert(!vm.map(0x1800, 0x1000, MemoryProtection::Read));
    assert(vm.findRegion(0x1000).has_value());
    assert(vm.findRegion(0x1FFF).has_value());
    assert(!vm.findRegion(0x2000).has_value());
    assert(vm.unmap(0x1000));

    HleRegistry reg;
    assert(reg.registerSymbol(0x1234, {"libTest", "test", [] { return 42; }}));
    assert(!reg.registerSymbol(0x1234, {"libTest", "duplicate", [] { return 0; }}));
    auto* sym = reg.resolve(0x1234);
    assert(sym && sym->function() == 42);

    std::cout << "PS5Bridge core tests passed\n";
    return 0;
}
