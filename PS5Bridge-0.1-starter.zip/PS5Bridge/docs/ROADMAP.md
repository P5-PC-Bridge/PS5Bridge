# Roadmap

## M0 - host foundation
- [x] CMake project
- [x] logging
- [x] ELF64 validation
- [x] program-header parser
- [x] guest-memory model
- [x] HLE registry
- [x] optional Vulkan enumeration
- [x] unit-test executable

## M1 - loader
- [ ] dynamic-section parser
- [ ] symbol/string tables
- [ ] relocation parsing
- [ ] module dependency graph
- [ ] import/NID representation
- [ ] PT_TLS parsing
- [ ] executable image mapping with host page protection
- [ ] structured compatibility report

## M2 - runtime
- [ ] ABI trampoline layer
- [ ] libkernel-compatible HLE surface
- [ ] threads/mutexes/condition variables
- [ ] clocks/timers
- [ ] virtual filesystem and mount mapping
- [ ] save-data sandbox
- [ ] input
- [ ] audio

## M3 - graphics
- [ ] Vulkan device/runtime layer
- [ ] GPU memory/resource model
- [ ] command-stream decoder framework
- [ ] shader IR
- [ ] shader -> SPIR-V translation
- [ ] render-target/depth/synchronization support
- [ ] GPU capture/replay diagnostics

## M4 - execution
- [ ] self-authored x86-64 test ELF
- [ ] native guest-code entry trampoline
- [ ] import calls into HLE
- [ ] controlled exception/crash capture
- [ ] deterministic regression tests

## M5 - compatibility
- [ ] per-title config database
- [ ] launcher/library UI
- [ ] controller profiles
- [ ] compatibility reports
- [ ] automated test captures
