# Architecture

PS5Bridge is intended as a clean-room user-space compatibility layer.

Target pipeline:

PS5 ELF/module
-> parser/loader
-> relocations/import resolver
-> HLE libraries + ABI bridge
-> guest-memory/thread/file abstractions
-> graphics command/shader translation
-> Vulkan
-> Windows

## Rules
1. No Sony source code.
2. No embedded firmware or keys.
3. No DRM/decryption component.
4. Tests should use self-authored ELF/homebrew fixtures whenever possible.
5. External code is imported only after license review.
